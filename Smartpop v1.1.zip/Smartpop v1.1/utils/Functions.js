// a function that take a date and format it  to better reading
function formatDate(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
   
    return new Date(date).toLocaleDateString('en-US', options);
}

export { formatDate };
