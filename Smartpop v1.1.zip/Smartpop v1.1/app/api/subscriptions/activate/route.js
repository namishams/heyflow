import { NextResponse } from 'next/server';
import { db } from '@/configs/db';
import { Users, UsersSubscriptions, SubscriptionsTypes, Invoices } from '@/configs/schema';
import { eq, or } from 'drizzle-orm';

const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const PAYPAL_SECRET = process.env.PAYPAL_SECRET;
const PAYPAL_BASE_URL = process.env.PAYPAL_STATUS === 'sandbox' ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

export async function POST(request) {
    try {
        // Get request data
        const { subscriptionId, orderID, planId } = await request.json();
        console.log('Received activation request:', { subscriptionId, orderID, planId });

        // Validate required fields
        if (!subscriptionId || !planId) {
            console.error('Missing required fields:', { subscriptionId, planId });
            return NextResponse.json(
                {
                    error: `Missing required fields: ${!subscriptionId ? 'subscriptionId' : ''} ${!planId ? 'planId' : ''}`.trim(),
                },
                { status: 400 }
            );
        }

        // Get subscription details from PayPal
        const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
        console.log('Fetching subscription details from PayPal');
        const paypalResponse = await fetch(`${PAYPAL_BASE_URL}/v1/billing/subscriptions/${subscriptionId}`, {
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Basic ${auth}`,
            },
        });

        if (!paypalResponse.ok) {
            const paypalError = await paypalResponse.text();
            console.error('Failed to fetch subscription details from PayPal:', {
                status: paypalResponse.status,
                statusText: paypalResponse.statusText,
                error: paypalError,
            });
            return NextResponse.json(
                {
                    error: 'Failed to verify subscription with PayPal',
                    details: paypalError,
                },
                { status: 400 }
            );
        }

        const paypalData = await paypalResponse.json();
        const email = paypalData.subscriber.email_address;
        console.log('PayPal subscription data:', {
            email,
            status: paypalData.status,
            planId: paypalData.plan_id,
        });

        // Get user from database
        const user = await db.select().from(Users).where(eq(Users.email, email)).limit(1);
        if (!user.length) {
            console.error('User not found for email:', email);
            return NextResponse.json(
                {
                    error: 'User not found',
                    details: 'No user account found with the PayPal email address',
                },
                { status: 404 }
            );
        }
        console.log('Found user:', { id: user[0].id, email: user[0].email });

        // Get subscription type
        const subscriptionType = await db
            .select()
            .from(SubscriptionsTypes)
            .where(or(eq(SubscriptionsTypes.paypalMonthlyPlanId, planId), eq(SubscriptionsTypes.paypalYearlyPlanId, planId)))
            .limit(1);

        if (!subscriptionType.length) {
            console.error('Subscription type not found for plan:', planId);
            return NextResponse.json(
                {
                    error: 'Subscription type not found',
                    details: 'The selected subscription plan was not found in our system',
                },
                { status: 404 }
            );
        }
        console.log('Found subscription type:', { id: subscriptionType[0].id, name: subscriptionType[0].name });

        const startDate = new Date();
        const endDate = new Date(paypalData.billing_info.next_billing_time);
        console.log('Subscription dates:', { startDate, endDate });

        // Check for existing subscription
        const existingSubscription = await db.select().from(UsersSubscriptions).where(eq(UsersSubscriptions.user_id, user[0].id)).limit(1);
        console.log('Existing subscription check:', { exists: existingSubscription.length > 0 });

        try {
            if (existingSubscription.length > 0) {
                console.log('Updating existing subscription');
                await db
                    .update(UsersSubscriptions)
                    .set({
                        paypal_subscription_id: subscriptionId,
                        subscription_type_id: subscriptionType[0].id,
                        payment_provider: 'paypal',
                        start_date: startDate,
                        end_date: endDate,
                        status: 'active',
                        auto_renew: true,
                    })
                    .where(eq(UsersSubscriptions.id, existingSubscription[0].id));
            } else {
                console.log('Creating new subscription');
                await db.insert(UsersSubscriptions).values({
                    user_id: user[0].id,
                    subscription_type_id: subscriptionType[0].id,
                    paypal_subscription_id: subscriptionId,
                    payment_provider: 'paypal',
                    start_date: startDate,
                    end_date: endDate,
                    status: 'active',
                    auto_renew: true,
                });
            }

            // Update user's subscription status
            await db
                .update(Users)
                .set({
                    subscription: true,
                    subscription_ends_at: endDate,
                })
                .where(eq(Users.id, user[0].id));

            // Create invoice record
            console.log('Creating invoice record');
            const invoiceNumber = `INV-PP-${Date.now()}`;
            await db.insert(Invoices).values({
                user_id: user[0].id,
                invoice_number: invoiceNumber,
                date: new Date(),
                amount: parseFloat(paypalData.billing_info.last_payment.amount.value),
                status: 'paid',
            });
            console.log('Successfully created invoice record');
        } catch (dbError) {
            console.error('Database operation failed:', dbError);
            return NextResponse.json(
                {
                    error: 'Failed to save subscription',
                    details: 'There was an error saving the subscription to our database',
                },
                { status: 500 }
            );
        }

        console.log('Subscription activation completed successfully');
        return NextResponse.json({
            success: true,
            message: 'Subscription activated successfully',
        });
    } catch (error) {
        console.error('Error activating subscription:', error);
        return NextResponse.json(
            {
                error: 'Internal server error',
                details: error.message,
            },
            { status: 500 }
        );
    }
}
