import { NextResponse } from 'next/server';
import { db } from '@/configs/db';
import { WebsitePaths, WebsitePopups, CollectedEmails, Websites } from '@/configs/schema';
import { eq, and } from 'drizzle-orm';

export async function DELETE(request) {
    try {
        const { websiteId, pathId, userId } = await request.json();

        if (!websiteId || !pathId || !userId) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        // Verify website ownership
        const website = await db
            .select()
            .from(Websites)
            .where(and(eq(Websites.id, websiteId), eq(Websites.user_id, userId)))
            .limit(1);

        if (!website.length) {
            return NextResponse.json({ error: 'Website not found or unauthorized' }, { status: 404 });
        }

        // Get all popups for this path first
        const popups = await db.select({ id: WebsitePopups.id }).from(WebsitePopups).where(eq(WebsitePopups.path_id, pathId));

        // 1. Delete collected emails for each popup
        for (const popup of popups) {
            await db.delete(CollectedEmails).where(eq(CollectedEmails.popup_id, popup.id));
        }

        // 2. Delete all popups in this path
        await db.delete(WebsitePopups).where(eq(WebsitePopups.path_id, pathId));

        // 3. Finally delete the path
        await db.delete(WebsitePaths).where(eq(WebsitePaths.id, pathId));

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Error deleting path:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
