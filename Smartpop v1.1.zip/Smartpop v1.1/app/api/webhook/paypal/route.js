import { NextResponse } from 'next/server';
import { db } from '@/configs/db';
import { Users, UsersSubscriptions, Invoices, SubscriptionsTypes } from '@/configs/schema';
import { eq, or } from 'drizzle-orm';

const PAYPAL_WEBHOOK_ID = process.env.PAYPAL_WEBHOOK_ID;
const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const PAYPAL_SECRET = process.env.PAYPAL_SECRET;
const PAYPAL_BASE_URL = process.env.PAYPAL_STATUS === 'sandbox' ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

// Helper function to verify PayPal webhook signature
async function verifyPayPalWebhook(req) {
    try {
        const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
        const response = await fetch(`${PAYPAL_BASE_URL}/v1/notifications/verify-webhook-signature`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Basic ${auth}`,
            },
            body: JSON.stringify({
                auth_algo: req.headers.get('paypal-auth-algo'),
                cert_url: req.headers.get('paypal-cert-url'),
                transmission_id: req.headers.get('paypal-transmission-id'),
                transmission_sig: req.headers.get('paypal-transmission-sig'),
                transmission_time: req.headers.get('paypal-transmission-time'),
                webhook_id: PAYPAL_WEBHOOK_ID,
                webhook_event: await req.json(),
            }),
        });

        const verification = await response.json();
        return verification.verification_status === 'SUCCESS';
    } catch (error) {
        console.error('PayPal webhook verification failed:', error);
        return false;
    }
}

// Helper function to get subscription type by PayPal plan ID
async function getSubscriptionTypeByPayPalPlanId(planId) {
    const subscriptionType = await db
        .select()
        .from(SubscriptionsTypes)
        .where(or(eq(SubscriptionsTypes.paypalMonthlyPlanId, planId), eq(SubscriptionsTypes.paypalYearlyPlanId, planId)))
        .limit(1);
    return subscriptionType[0];
}

// Helper function to get user by email
async function getUserByEmail(email) {
    const user = await db.select().from(Users).where(eq(Users.email, email)).limit(1);
    return user[0];
}

// Helper function to reset user's project
async function resetUserProject(userId) {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/user/reset-project`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId }),
        });

        if (!response.ok) {
            console.error('Failed to reset project for user:', userId);
        }
    } catch (error) {
        console.error('Error resetting project:', error);
    }
}

export async function POST(request) {
    console.log('PayPal webhook received:', new Date().toISOString());

    // Clone request for verification
    const reqForVerification = request.clone();
    const reqForProcessing = request.clone();

    // Log raw event before verification
    const rawEvent = await reqForProcessing.json();
    console.log('Raw webhook event:', {
        event_type: rawEvent.event_type,
        resource_type: rawEvent.resource_type,
        resource_id: rawEvent.resource?.id,
        summary: rawEvent.summary,
    });

    // Verify webhook signature
    if (!(await verifyPayPalWebhook(reqForVerification))) {
        console.error('Webhook signature verification failed');
        return NextResponse.json({ error: 'Invalid webhook signature' }, { status: 400 });
    }
    console.log('Webhook signature verified successfully');

    const event = rawEvent;
    const eventType = event.event_type;

    try {
        console.log('Processing webhook event:', {
            eventType,
            resourceId: event.resource?.id,
            timestamp: new Date().toISOString(),
        });

        switch (eventType) {
            case 'BILLING.SUBSCRIPTION.ACTIVATED': {
                console.log('Processing subscription activation');
                const subscription = event.resource;
                const subscriptionId = subscription.id;
                const planId = subscription.plan_id;
                console.log('Subscription details:', {
                    subscriptionId,
                    planId,
                    status: subscription.status,
                    billing_info: subscription.billing_info,
                });

                // Get subscription details from PayPal API
                const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
                console.log('Fetching subscription details from PayPal API');
                const paypalResponse = await fetch(`${PAYPAL_BASE_URL}/v1/billing/subscriptions/${subscriptionId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Basic ${auth}`,
                    },
                });

                if (!paypalResponse.ok) {
                    console.error('Failed to fetch subscription details from PayPal:', {
                        status: paypalResponse.status,
                        statusText: paypalResponse.statusText,
                    });
                    break;
                }

                const paypalData = await paypalResponse.json();
                const email = paypalData.subscriber.email_address;
                console.log('PayPal subscription data:', {
                    email,
                    status: paypalData.status,
                    planId: paypalData.plan_id,
                });

                // Get subscription type from plan ID
                const subscriptionType = await getSubscriptionTypeByPayPalPlanId(planId);
                if (!subscriptionType) {
                    console.error('No subscription type found for PayPal plan ID:', planId);
                    break;
                }
                console.log('Found subscription type:', {
                    id: subscriptionType.id,
                    name: subscriptionType.name,
                    planId: planId,
                });

                // Get user by email
                const user = await getUserByEmail(email);
                if (!user) {
                    console.error('No user found for email:', email);
                    break;
                }
                console.log('Found user:', {
                    id: user.id,
                    email: user.email,
                });

                const startDate = new Date();
                const endDate = new Date(subscription.billing_info.next_billing_time);
                console.log('Subscription dates:', {
                    startDate,
                    endDate,
                    next_billing: subscription.billing_info.next_billing_time,
                });

                // Check for existing subscription
                const existingSubscription = await db.select().from(UsersSubscriptions).where(eq(UsersSubscriptions.user_id, user.id)).limit(1);
                console.log('Existing subscription check:', {
                    exists: existingSubscription.length > 0,
                    subscriptionId: existingSubscription[0]?.id,
                });

                if (existingSubscription.length > 0) {
                    console.log('Updating existing subscription');
                    // Update existing subscription
                    await db
                        .update(UsersSubscriptions)
                        .set({
                            paypal_subscription_id: subscriptionId,
                            subscription_type_id: subscriptionType.id,
                            payment_provider: 'paypal',
                            start_date: startDate,
                            end_date: endDate,
                            status: 'active',
                            auto_renew: true,
                        })
                        .where(eq(UsersSubscriptions.id, existingSubscription[0].id));
                    console.log('Successfully updated existing subscription');
                } else {
                    console.log('Creating new subscription');
                    // Create new subscription
                    await db.insert(UsersSubscriptions).values({
                        user_id: user.id,
                        subscription_type_id: subscriptionType.id,
                        paypal_subscription_id: subscriptionId,
                        payment_provider: 'paypal',
                        start_date: startDate,
                        end_date: endDate,
                        status: 'active',
                        auto_renew: true,
                    });
                    console.log('Successfully created new subscription');
                }

                console.log('Updating user subscription status');
                // Update user's subscription status
                await db
                    .update(Users)
                    .set({
                        subscription: true,
                        subscription_ends_at: endDate,
                    })
                    .where(eq(Users.id, user.id));
                console.log('Successfully updated user subscription status');

                console.log('Creating invoice record');
                // Create invoice record
                const invoiceNumber = `INV-PP-${Date.now()}`;
                await db.insert(Invoices).values({
                    user_id: user.id,
                    invoice_number: invoiceNumber,
                    date: new Date(),
                    amount: parseFloat(subscription.billing_info.last_payment.amount.value),
                    status: 'paid',
                });
                console.log('Successfully created invoice record');
                break;
            }

            case 'BILLING.SUBSCRIPTION.CANCELLED':
            case 'BILLING.SUBSCRIPTION.EXPIRED':
            case 'BILLING.SUBSCRIPTION.SUSPENDED': {
                console.log('Processing subscription cancellation/expiration/suspension');
                const subscription = event.resource;
                const subscriptionId = subscription.id;
                console.log('Cancellation details:', { subscriptionId, status: subscription.status });

                // Get subscription details from PayPal API to ensure we have the latest data
                const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
                const paypalResponse = await fetch(`${PAYPAL_BASE_URL}/v1/billing/subscriptions/${subscriptionId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Basic ${auth}`,
                    },
                });

                if (!paypalResponse.ok) {
                    console.error('Failed to fetch subscription details from PayPal:', {
                        status: paypalResponse.status,
                        statusText: paypalResponse.statusText,
                    });
                    break;
                }

                const paypalData = await paypalResponse.json();
                console.log('PayPal subscription data:', {
                    status: paypalData.status,
                    subscriptionId: paypalData.id,
                });

                // Find the user subscription in our database
                const userSubscription = await db.select().from(UsersSubscriptions).where(eq(UsersSubscriptions.paypal_subscription_id, subscriptionId)).limit(1);
                console.log('Found user subscription:', {
                    exists: userSubscription.length > 0,
                    subscriptionId: userSubscription[0]?.id,
                    userId: userSubscription[0]?.user_id,
                });

                if (userSubscription.length > 0) {
                    try {
                        console.log('Updating subscription status to inactive');
                        // Update subscription status
                        await db
                            .update(UsersSubscriptions)
                            .set({
                                status: 'inactive',
                                auto_renew: false,
                                end_date: new Date(), // Set end date to now since subscription is cancelled
                            })
                            .where(eq(UsersSubscriptions.paypal_subscription_id, subscriptionId));
                        console.log('Successfully updated subscription status');

                        console.log('Updating user subscription flag');
                        // Update user's subscription status
                        await db
                            .update(Users)
                            .set({
                                subscription: false,
                                subscription_ends_at: new Date(), // Set to current date as subscription is ended
                            })
                            .where(eq(Users.id, userSubscription[0].user_id));
                        console.log('Successfully updated user subscription flag');

                        // Reset user's project
                        console.log('Resetting user project');
                        await resetUserProject(userSubscription[0].user_id);
                        console.log('Successfully reset user project');
                    } catch (error) {
                        console.error('Error updating subscription status:', error);
                    }
                } else {
                    console.log('No subscription found in database for PayPal subscription ID:', subscriptionId);
                }
                break;
            }

            case 'PAYMENT.SALE.COMPLETED': {
                console.log('Processing payment sale completion');
                const sale = event.resource;
                const subscriptionId = sale.billing_agreement_id;
                console.log('Payment details:', {
                    sale_id: sale.id,
                    subscriptionId,
                    amount: sale.amount,
                });

                if (!subscriptionId) {
                    console.log('No billing_agreement_id found, skipping');
                    break;
                }

                // Get subscription details from PayPal API
                const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
                const billingAgreementResponse = await fetch(`${PAYPAL_BASE_URL}/v1/billing/subscriptions/${subscriptionId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Basic ${auth}`,
                    },
                });

                if (!billingAgreementResponse.ok) {
                    console.error('Failed to fetch billing agreement details');
                    break;
                }

                const billingAgreement = await billingAgreementResponse.json();
                const email = billingAgreement.subscriber.email_address;
                const planId = billingAgreement.plan_id;
                console.log('PayPal subscription details:', { email, planId });

                // Try to find existing subscription
                const userSubscription = await db.select().from(UsersSubscriptions).where(eq(UsersSubscriptions.paypal_subscription_id, subscriptionId)).limit(1);

                if (userSubscription.length > 0) {
                    console.log('Existing subscription found, updating');
                    // Add new invoice record
                    await db.insert(Invoices).values({
                        user_id: userSubscription[0].user_id,
                        invoice_number: `INV-PP-${Date.now()}`,
                        date: new Date(),
                        amount: parseFloat(sale.amount.total),
                        status: 'paid',
                    });

                    // Update subscription end date
                    const newEndDate = new Date(userSubscription[0].end_date);
                    newEndDate.setMonth(newEndDate.getMonth() + 1);

                    await db
                        .update(UsersSubscriptions)
                        .set({
                            end_date: newEndDate,
                            status: 'active',
                        })
                        .where(eq(UsersSubscriptions.id, userSubscription[0].id));

                    // Update user's subscription status
                    await db
                        .update(Users)
                        .set({
                            subscription: true,
                            subscription_ends_at: newEndDate,
                        })
                        .where(eq(Users.id, userSubscription[0].user_id));
                } else {
                    console.log('No existing subscription found, creating new subscription');

                    // Get subscription type from plan ID
                    const subscriptionType = await getSubscriptionTypeByPayPalPlanId(planId);
                    if (!subscriptionType) {
                        console.error('No subscription type found for PayPal plan ID:', planId);
                        break;
                    }
                    console.log('Found subscription type:', subscriptionType);

                    const user = await getUserByEmail(email);
                    if (!user) {
                        console.error('No user found for email:', email);
                        break;
                    }
                    console.log('Found user:', user);

                    const startDate = new Date();
                    const endDate = new Date();
                    endDate.setMonth(endDate.getMonth() + 1);

                    // Create new subscription
                    await db.insert(UsersSubscriptions).values({
                        user_id: user.id,
                        subscription_type_id: subscriptionType.id,
                        paypal_subscription_id: subscriptionId,
                        payment_provider: 'paypal',
                        start_date: startDate,
                        end_date: endDate,
                        status: 'active',
                        auto_renew: true,
                    });

                    // Update user's subscription status
                    await db
                        .update(Users)
                        .set({
                            subscription: true,
                            subscription_ends_at: endDate,
                        })
                        .where(eq(Users.id, user.id));

                    // Create invoice record
                    await db.insert(Invoices).values({
                        user_id: user.id,
                        invoice_number: `INV-PP-${Date.now()}`,
                        date: new Date(),
                        amount: parseFloat(sale.amount.total),
                        status: 'paid',
                    });
                }
                break;
            }
        }
    } catch (err) {
        console.error(`PayPal webhook handling failed: ${err.message}`);
        return NextResponse.json({ error: err.message }, { status: 400 });
    }

    return NextResponse.json({ message: 'Webhook processed successfully' });
}
