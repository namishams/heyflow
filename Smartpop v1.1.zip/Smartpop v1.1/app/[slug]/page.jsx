import { notFound } from 'next/navigation';
import { getPageBySlug } from '@/utils/AdminUtils';

async function getPageData(slug) {
    const pageData = await getPageBySlug(slug);
    return pageData;
}

export default async function DynamicPage({ params }) {
    const pageData = await getPageData(params.slug);

    if (!pageData) {
        notFound();
    }

    return (
        <div className="min-h-screen mt-24 bg-background">
            <div
                className="max-w-[1300px] mx-auto px-4 my-10 prose prose-lg dark:prose-invert prose-headings:font-bold prose-h1:text-4xl prose-h2:text-3xl prose-h3:text-2xl prose-h4:text-xl prose-h5:text-lg prose-h6:text-base prose-headings:text-foreground prose-p:text-muted-foreground prose-a:text-primary hover:prose-a:text-primary/90"
                dangerouslySetInnerHTML={{ __html: pageData.content }}
            />
        </div>
    );
}
